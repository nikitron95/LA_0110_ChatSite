
import ChatApp from './components/ChatLIst'
import Login from './components/Login'

function App() {
  return(<>
  <Login/>
  <ChatApp/>
  </>)
}
export default App
